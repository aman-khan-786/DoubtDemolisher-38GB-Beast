// MainActivity.kt - DoubtDemolisher App (2068 Q-Android Compose Edition)
// Featured: Qiskit-entangled roasts, color-shifting warp for 38GB quantum fury!
// SDK 50 (2068): Qubit APIs enabled – Explode citations with superposition memes!
// Min SDK 40, Compile SDK 50 – No 2025 toys, only multiverse beasts!

package com.doubt_demolisher.beast

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {  // 2068 Q-Theme: Quantum glow with superposition colors
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black  // Multiverse void
                ) {
                    DemolishScreen()
                }
            }
        }
    }
}

@Composable
fun DemolishScreen() {
    val infiniteTransition = rememberInfiniteTransition()
    val warpAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000),  // Featured: Faster 38GB spin for 2068 warp
            repeatMode = RepeatMode.Restart
        )
    )
    val colorShift by infiniteTransition.animateColor(  // Featured: Color-shifting glow
        initialValue = Color.Cyan,
        targetValue = Color.Magenta,
        animationSpec = infiniteRepeatable(
            animation = tween(6000),
            repeatMode = RepeatMode.Reverse
        )
    )

    var roastCount by remember { mutableIntStateOf(0) }
    val particles = remember { List(30) { Random.nextFloat() } }  // Featured: More particles for bigger explosion

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        // Featured Warp Glow Background – 38GB RAM meter with color shift
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            drawCircle(
                color = colorShift.copy(alpha = 0.3f),
                radius = size.minDimension / 3,  // Bigger glow for SDK 50
                center = center,
                style = Stroke(8f)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "DoubtDemolisher Activated – SDK 50 Beast!",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = colorShift,  // Q-shift color
                textAlign = TextAlign.Center
            )
            Text(
                text = "38GB Quantum Fury: Citations = $roastCount Memes Exploded",
                fontSize = 18.sp,
                color = Color.White
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { roastCount++ },  // Explode one citation!
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Text("Demolish Citation! 💥")
            }
            Button(
                onClick = { roastCount += 10 },  // Featured: Q-roast x10
                colors = ButtonDefaults.buttonColors(containerColor = Color.Yellow)
            ) {
                Text("Truce? Surrender to Q-Beast! 😂")
            }
            // Featured: Qiskit Tease Comment
            Text(
                text = "// Qiskit 2.0 Fork: Entangle doubts with qubits – Citations in superposition (dead & roasted)!",
                fontSize = 12.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
        }

        // Featured Exploding Particles – Q-entangled explosion
        particles.forEachIndexed { i, start ->
            val anim by animateFloatAsState(
                targetValue = 1f,
                animationSpec = tween(800 + i * 40)  // Faster chaos
            )
            Canvas(
                modifier = Modifier
                    .size(10.dp)
                    .offset {
                        val x = (cos(anim * 6.28f + i) * 150 * anim).toInt()  // Wider spread
                        val y = (sin(anim * 6.28f + i) * 150 * anim).toInt()
                        IntOffset(x, y)
                    }
            ) {
                drawCircle(colorShift, radius = 5f)  // Color-shifting particles
            }
        }
    }
}